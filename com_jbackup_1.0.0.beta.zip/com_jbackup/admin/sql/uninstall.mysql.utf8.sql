DROP TABLE IF EXISTS `#__jbackup_backups`;
