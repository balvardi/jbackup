<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_jbackup
 *
 * @copyright   Copyright (C) 2025 R.Balvardi. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\FormController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;

/**
 * Backup Controller
 *
 * @package     Joomla.Administrator
 * @subpackage  com_jbackup
 */
class JBackupControllerBackup extends FormController
{
    /**
     * Method to run a backup
     *
     * @return  void
     */
    public function runBackup()
    {
        // Check for request forgeries
        Session::checkToken() or die(Text::_('JINVALID_TOKEN'));

        // Get the input
        $app = Factory::getApplication();
        $input = $app->input;
        $data = $input->get('jform', [], 'array');

        // Get the model
        $model = $this->getModel('Backup', 'JBackupModel');

        // Attempt to run the backup
        if ($model->runBackup($data)) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_BACKUP_SUCCESS'), 'success');
        } else {
            $app->enqueueMessage(Text::_('COM_JBACKUP_BACKUP_FAILED'), 'error');
        }

        // Redirect back to the backup form
        $this->setRedirect(Route::_('index.php?option=com_jbackup&view=backup', false));
    }

    /**
     * Method to download a backup
     *
     * @return  void
     */
    public function download()
    {
        // Check for request forgeries
        Session::checkToken('get') or die(Text::_('JINVALID_TOKEN'));

        // Get the input
        $app = Factory::getApplication();
        $input = $app->input;
        $id = $input->getInt('id');

        // Get the model
        $model = $this->getModel('Backup', 'JBackupModel');

        // Attempt to download the backup
        if (!$model->downloadBackup($id)) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_DOWNLOAD_FAILED'), 'error');
            $this->setRedirect(Route::_('index.php?option=com_jbackup&view=backups', false));
        }
    }

    /**
     * Method to restore a backup
     *
     * @return  void
     */
    public function restore()
    {
        // Check for request forgeries
        Session::checkToken('get') or die(Text::_('JINVALID_TOKEN'));

        // Get the input
        $app = Factory::getApplication();
        $input = $app->input;
        $id = $input->getInt('id');

        // Get the model
        $model = $this->getModel('Backup', 'JBackupModel');

        // Attempt to restore the backup
        if ($model->restoreBackup($id)) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_RESTORE_SUCCESS'), 'success');
        } else {
            $app->enqueueMessage(Text::_('COM_JBACKUP_RESTORE_FAILED'), 'error');
        }

        // Redirect back to the backups list
        $this->setRedirect(Route::_('index.php?option=com_jbackup&view=backups', false));
    }

    /**
     * Method to delete a backup
     *
     * @return  void
     */
    public function delete()
    {
        // Check for request forgeries
        Session::checkToken('get') or die(Text::_('JINVALID_TOKEN'));

        // Get the input
        $app = Factory::getApplication();
        $input = $app->input;
        $id = $input->getInt('id');

        // Get the model
        $model = $this->getModel('Backup', 'JBackupModel');

        // Attempt to delete the backup
        if ($model->deleteBackup($id)) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_DELETE_SUCCESS'), 'success');
        } else {
            $app->enqueueMessage(Text::_('COM_JBACKUP_DELETE_FAILED'), 'error');
        }

        // Redirect back to the backups list
        $this->setRedirect(Route::_('index.php?option=com_jbackup&view=backups', false));
    }
}
