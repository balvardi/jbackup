<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_jbackup
 *
 * @copyright   Copyright (C) 2025 R.Balvardi. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

/**
 * Backup Table class
 *
 * @package     Joomla.Administrator
 * @subpackage  com_jbackup
 */
class JBackupTableBackup extends Table
{
    /**
     * Constructor
     *
     * @param   DatabaseDriver  $db  Database driver object.
     */
    public function __construct(DatabaseDriver $db)
    {
        parent::__construct('#__jbackup_backups', 'id', $db);
    }
}
