<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_jbackup
 *
 * @copyright   Copyright (C) 2025 R.Balvardi. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Access\Access;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Object\CMSObject;

/**
 * JBackup component helper.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_jbackup
 */
class JBackupHelper
{
    /**
     * Configure the Linkbar.
     *
     * @param   string  $vName  The name of the active view.
     *
     * @return  void
     */
    public static function addSubmenu($vName)
    {
        JHtmlSidebar::addEntry(
            Text::_('COM_JBACKUP_SUBMENU_BACKUPS'),
            'index.php?option=com_jbackup&view=backups',
            $vName == 'backups'
        );

        JHtmlSidebar::addEntry(
            Text::_('COM_JBACKUP_SUBMENU_BACKUP'),
            'index.php?option=com_jbackup&view=backup&layout=edit',
            $vName == 'backup'
        );

        JHtmlSidebar::addEntry(
            Text::_('COM_JBACKUP_SUBMENU_SETTINGS'),
            'index.php?option=com_config&view=component&component=com_jbackup',
            $vName == 'settings'
        );
    }

    /**
     * Gets a list of the actions that can be performed.
     *
     * @return  CMSObject
     */
    public static function getActions()
    {
        $user   = Factory::getUser();
        $result = new CMSObject;

        $actions = Access::getActionsFromFile(
            JPATH_ADMINISTRATOR . '/components/com_jbackup/access.xml',
            "/access/section[@name='component']/"
        );

        foreach ($actions as $action) {
            $result->set($action->name, $user->authorise($action->name, 'com_jbackup'));
        }

        return $result;
    }

    /**
     * Format file size
     *
     * @param   integer  $bytes     File size in bytes
     * @param   integer  $decimals  Number of decimals
     *
     * @return  string  Formatted file size
     */
    public static function formatSize($bytes, $decimals = 2)
    {
        $size = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        $factor = floor((strlen($bytes) - 1) / 3);
        return sprintf("%.{$decimals}f", $bytes / pow(1024, $factor)) . ' ' . @$size[$factor];
    }
}
