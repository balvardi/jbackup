<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_jbackup
 *
 * @copyright   Copyright (C) 2025 R.Balvardi. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;

/**
 * Backup View
 *
 * @package     Joomla.Administrator
 * @subpackage  com_jbackup
 */
class JBackupViewBackup extends HtmlView
{
    /**
     * The form object
     *
     * @var  \Joomla\CMS\Form\Form
     */
    protected $form;

    /**
     * The active item
     *
     * @var  object
     */
    protected $item;

    /**
     * The model state
     *
     * @var  \Joomla\CMS\Object\CMSObject
     */
    protected $state;

    /**
     * Display the view
     *
     * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
     *
     * @return  mixed  A string if successful, otherwise an Error object.
     */
    public function display($tpl = null)
    {
        // Get the data
        $this->form = $this->get('Form');
        $this->item = $this->get('Item');
        $this->state = $this->get('State');

        // Check for errors.
        if (count($errors = $this->get('Errors'))) {
            throw new Exception(implode("\n", $errors), 500);
        }

        // Set the toolbar
        $this->addToolBar();

        // Display the template
        return parent::display($tpl);
    }

    /**
     * Add the page title and toolbar.
     *
     * @return  void
     */
    protected function addToolBar()
    {
        Factory::getApplication()->input->set('hidemainmenu', true);

        $isNew = ($this->item->id == 0);

        ToolbarHelper::title(
            Text::_('COM_JBACKUP_MANAGER_' . ($isNew ? 'NEW' : 'EDIT') . '_BACKUP'),
            'database'
        );

        ToolbarHelper::apply('backup.apply');
        ToolbarHelper::save('backup.save');
        ToolbarHelper::save2new('backup.save2new');

        if (!$isNew) {
            ToolbarHelper::save2copy('backup.save2copy');
        }

        ToolbarHelper::cancel('backup.cancel', $isNew ? 'JTOOLBAR_CANCEL' : 'JTOOLBAR_CLOSE');
        ToolbarHelper::divider();
        ToolbarHelper::help('JHELP_COMPONENTS_JBACKUP_BACKUP_EDIT');
    }
}
