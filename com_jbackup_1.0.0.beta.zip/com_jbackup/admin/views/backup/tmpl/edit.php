<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_jbackup
 *
 * @copyright   Copyright (C) 2025 R.Balvardi. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;

HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('behavior.keepalive');
HTMLHelper::_('formbehavior.chosen', 'select');

$app = Factory::getApplication();
$input = $app->input;

// In case of modal
$isModal = $input->get('layout') == 'modal' ? true : false;
$layout  = $isModal ? 'modal' : 'edit';
$tmpl    = $isModal || $input->get('tmpl', '') === 'component' ? '&tmpl=component' : '';
?>

<form action="<?php echo Route::_('index.php?option=com_jbackup&layout=' . $layout . $tmpl . '&id=' . (int) $this->item->id); ?>" method="post" name="adminForm" id="backup-form" class="form-validate">

    <?php echo LayoutHelper::render('joomla.edit.title_alias', $this); ?>

    <div class="form-horizontal">
        <?php echo HTMLHelper::_('bootstrap.startTabSet', 'myTab', ['active' => 'details']); ?>

        <?php echo HTMLHelper::_('bootstrap.addTab', 'myTab', 'details', Text::_('COM_JBACKUP_BACKUP_TAB_DETAILS')); ?>
        <div class="row-fluid">
            <div class="span9">
                <div class="form-vertical">
                    <?php echo $this->form->renderField('name'); ?>
                    <?php echo $this->form->renderField('type'); ?>
                    <?php echo $this->form->renderField('exclude_cache'); ?>
                    <?php echo $this->form->renderField('exclude_logs'); ?>
                    <?php echo $this->form->renderField('exclude_tmp'); ?>
                </div>
            </div>
            <div class="span3">
                <div class="form-vertical">
                    <?php if (!empty($this->item->id)): ?>
                        <div class="control-group">
                            <div class="control-label">
                                <?php echo $this->form->getLabel('id'); ?>
                            </div>
                            <div class="controls">
                                <?php echo $this->form->getInput('id'); ?>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="control-label">
                                <?php echo $this->form->getLabel('created'); ?>
                            </div>
                            <div class="controls">
                                <?php echo $this->item->created; ?>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="control-label">
                                <?php echo $this->form->getLabel('created_by'); ?>
                            </div>
                            <div class="controls">
                                <?php echo $this->item->created_by_name; ?>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="control-label">
                                <?php echo $this->form->getLabel('status'); ?>
                            </div>
                            <div class="controls">
                                <?php echo $this->item->status; ?>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="control-label">
                                <?php echo $this->form->getLabel('size'); ?>
                            </div>
                            <div class="controls">
                                <?php echo JHtml::_('number.bytes', $this->item->size); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php echo HTMLHelper::_('bootstrap.endTab'); ?>

        <?php echo HTMLHelper::_('bootstrap.endTabSet'); ?>
    </div>

    <input type="hidden" name="task" value="" />
    <?php echo HTMLHelper::_('form.token'); ?>
</form>
