<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_jbackup
 *
 * @copyright   Copyright (C) 2025 R.Balvardi. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');

$user      = Factory::getUser();
$userId    = $user->get('id');
$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));
$saveOrder = $listOrder == 'a.ordering';
$canOrder  = $user->authorise('core.edit.state', 'com_jbackup');
$canCreate = $user->authorise('core.create', 'com_jbackup');
$canEdit   = $user->authorise('core.edit', 'com_jbackup');
$canDelete = $user->authorise('core.delete', 'com_jbackup');
?>

<form action="<?php echo Route::_('index.php?option=com_jbackup&view=backups'); ?>" method="post" name="adminForm" id="adminForm">
    <div id="j-sidebar-container" class="span2">
        <?php echo JHtmlSidebar::render(); ?>
    </div>
    <div id="j-main-container" class="span10">
        <?php
        // Search tools bar
        echo LayoutHelper::render('joomla.searchtools.default', ['view' => $this]);
        ?>
        <?php if (empty($this->items)) : ?>
            <div class="alert alert-no-items">
                <?php echo Text::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
            </div>
        <?php else : ?>
            <table class="table table-striped" id="backupList">
                <thead>
                    <tr>
                        <th width="1%" class="hidden-phone">
                            <?php echo HTMLHelper::_('grid.checkall'); ?>
                        </th>
                        <th width="1%" style="min-width:55px" class="nowrap center">
                            <?php echo HTMLHelper::_('searchtools.sort', 'JSTATUS', 'a.status', $listDirn, $listOrder); ?>
                        </th>
                        <th>
                            <?php echo HTMLHelper::_('searchtools.sort', 'COM_JBACKUP_HEADING_NAME', 'a.name', $listDirn, $listOrder); ?>
                        </th>
                        <th width="10%" class="nowrap hidden-phone">
                            <?php echo HTMLHelper::_('searchtools.sort', 'COM_JBACKUP_HEADING_TYPE', 'a.type', $listDirn, $listOrder); ?>
                        </th>
                        <th width="10%" class="nowrap hidden-phone">
                            <?php echo HTMLHelper::_('searchtools.sort', 'COM_JBACKUP_HEADING_SIZE', 'a.size', $listDirn, $listOrder); ?>
                        </th>
                        <th width="15%" class="nowrap hidden-phone">
                            <?php echo HTMLHelper::_('searchtools.sort', 'COM_JBACKUP_HEADING_CREATED', 'a.created', $listDirn, $listOrder); ?>
                        </th>
                        <th width="10%" class="nowrap hidden-phone">
                            <?php echo HTMLHelper::_('searchtools.sort', 'COM_JBACKUP_HEADING_CREATED_BY', 'a.created_by', $listDirn, $listOrder); ?>
                        </th>
                        <th width="1%" class="nowrap hidden-phone">
                            <?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?>
                        </th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <td colspan="8">
                            <?php echo $this->pagination->getListFooter(); ?>
                        </td>
                    </tr>
                </tfoot>
                <tbody>
                    <?php foreach ($this->items as $i => $item) :
                        $canEdit    = $user->authorise('core.edit', 'com_jbackup');
                        $canCheckin = $user->authorise('core.manage', 'com_checkin');
                        $canChange  = $user->authorise('core.edit.state', 'com_jbackup');
                    ?>
                        <tr class="row<?php echo $i % 2; ?>">
                            <td class="center hidden-phone">
                                <?php echo HTMLHelper::_('grid.id', $i, $item->id); ?>
                            </td>
                            <td class="center">
                                <?php if ($item->status == 'completed') : ?>
                                    <span class="badge badge-success"><?php echo Text::_('COM_JBACKUP_STATUS_COMPLETED'); ?></span>
                                <?php else : ?>
                                    <span class="badge badge-important"><?php echo Text::_('COM_JBACKUP_STATUS_FAILED'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($canEdit) : ?>
                                    <a href="<?php echo Route::_('index.php?option=com_jbackup&task=backup.edit&id=' . (int) $item->id); ?>">
                                        <?php echo $this->escape($item->name); ?>
                                    </a>
                                <?php else : ?>
                                    <?php echo $this->escape($item->name); ?>
                                <?php endif; ?>
                                <div class="small">
                                    <div class="btn-group">
                                        <?php if ($item->status == 'completed') : ?>
                                            <a class="btn btn-small btn-info" href="<?php echo Route::_('index.php?option=com_jbackup&task=backup.download&id=' . (int) $item->id . '&' . Session::getFormToken() . '=1'); ?>">
                                                <span class="icon-download"></span> <?php echo Text::_('COM_JBACKUP_DOWNLOAD'); ?>
                                            </a>
                                            <a class="btn btn-small btn-warning" href="<?php echo Route::_('index.php?option=com_jbackup&task=backup.restore&id=' . (int) $item->id . '&' . Session::getFormToken() . '=1'); ?>" onclick="return confirm('<?php echo Text::_('COM_JBACKUP_CONFIRM_RESTORE'); ?>');">
                                                <span class="icon-refresh"></span> <?php echo Text::_('COM_JBACKUP_RESTORE'); ?>
                                            </a>
                                        <?php endif; ?>
                                        <a class="btn btn-small btn-danger" href="<?php echo Route::_('index.php?option=com_jbackup&task=backup.delete&id=' . (int) $item->id . '&' . Session::getFormToken() . '=1'); ?>" onclick="return confirm('<?php echo Text::_('COM_JBACKUP_CONFIRM_DELETE'); ?>');">
                                            <span class="icon-trash"></span> <?php echo Text::_('COM_JBACKUP_DELETE'); ?>
                                        </a>
                                    </div>
                                </div>
                            </td>
                            <td class="small hidden-phone">
                                <?php
                                switch ($item->type) {
                                    case 'full':
                                        echo Text::_('COM_JBACKUP_TYPE_FULL');
                                        break;
                                    case 'files':
                                        echo Text::_('COM_JBACKUP_TYPE_FILES');
                                        break;
                                    case 'database':
                                        echo Text::_('COM_JBACKUP_TYPE_DATABASE');
                                        break;
                                }
                                ?>
                            </td>
                            <td class="small hidden-phone">
                                <?php echo HTMLHelper::_('number.bytes', $item->size); ?>
                            </td>
                            <td class="small hidden-phone">
                                <?php echo HTMLHelper::_('date', $item->created, Text::_('DATE_FORMAT_LC2')); ?>
                            </td>
                            <td class="small hidden-phone">
                                <?php echo $this->escape($item->created_by_name); ?>
                            </td>
                            <td class="center hidden-phone">
                                <?php echo (int) $item->id; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <input type="hidden" name="task" value="" />
        <input type="hidden" name="boxchecked" value="0" />
        <?php echo HTMLHelper::_('form.token'); ?>
    </div>
</form>
