<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_jbackup
 *
 * @copyright   Copyright (C) 2025 R.Balvardi. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Filesystem\Path;
use Joomla\CMS\Date\Date;

/**
 * Backup Model
 *
 * @package     Joomla.Administrator
 * @subpackage  com_jbackup
 */
class JBackupModelBackup extends AdminModel
{
    /**
     * Method to get a table object, load it if necessary.
     *
     * @param   string  $type    The table name. Optional.
     * @param   string  $prefix  The class prefix. Optional.
     * @param   array   $config  Configuration array for model. Optional.
     *
     * @return  Table  A Table object
     */
    public function getTable($type = 'Backup', $prefix = 'JBackupTable', $config = [])
    {
        return Table::getInstance($type, $prefix, $config);
    }

    /**
     * Method to get the record form.
     *
     * @param   array    $data      Data for the form.
     * @param   boolean  $loadData  True if the form is to load its own data (default case), false if not.
     *
     * @return  mixed    A JForm object on success, false on failure
     */
    public function getForm($data = [], $loadData = true)
    {
        // Get the form.
        $form = $this->loadForm(
            'com_jbackup.backup',
            'backup',
            [
                'control' => 'jform',
                'load_data' => $loadData
            ]
        );

        if (empty($form)) {
            return false;
        }

        return $form;
    }

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return  mixed  The data for the form.
     */
    protected function loadFormData()
    {
        // Check the session for previously entered form data.
        $data = Factory::getApplication()->getUserState(
            'com_jbackup.edit.backup.data',
            []
        );

        if (empty($data)) {
            $data = $this->getItem();
        }

        return $data;
    }

    /**
     * Method to run a backup
     *
     * @param   array  $data  The form data
     *
     * @return  boolean  True on success, false on failure
     */
    public function runBackup($data)
    {
        // Initialize variables
        $app = Factory::getApplication();
        $db = Factory::getDbo();
        $user = Factory::getUser();
        $date = new Date('now', Factory::getConfig()->get('offset'));
        
        // Set up backup parameters
        $backupName = !empty($data['name']) ? $data['name'] : 'joomla-backup-' . $date->format('Y-m-d-H-i-s');
        $backupType = !empty($data['type']) ? $data['type'] : 'full';
        $excludeCache = !empty($data['exclude_cache']);
        $excludeLogs = !empty($data['exclude_logs']);
        $excludeTmp = !empty($data['exclude_tmp']);
        
        // Create backup directory if it doesn't exist
        $backupDir = JPATH_ADMINISTRATOR . '/components/com_jbackup/backups';
        if (!Folder::exists($backupDir)) {
            if (!Folder::create($backupDir)) {
                $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_CREATING_BACKUP_DIR'), 'error');
                return false;
            }
        }
        
        // Create a unique backup folder for this backup
        $backupPath = $backupDir . '/' . $backupName;
        if (!Folder::create($backupPath)) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_CREATING_BACKUP_PATH'), 'error');
            return false;
        }
        
        // Initialize backup status
        $backupStatus = true;
        $backupSize = 0;
        $backupFiles = [];
        
        // Backup database if requested
        if ($backupType == 'full' || $backupType == 'database') {
            $backupStatus = $backupStatus && $this->backupDatabase($backupPath, $backupFiles);
        }
        
        // Backup files if requested
        if ($backupType == 'full' || $backupType == 'files') {
            $excludeFolders = [];
            
            if ($excludeCache) {
                $excludeFolders[] = JPATH_SITE . '/cache';
                $excludeFolders[] = JPATH_ADMINISTRATOR . '/cache';
            }
            
            if ($excludeLogs) {
                $excludeFolders[] = JPATH_ADMINISTRATOR . '/logs';
            }
            
            if ($excludeTmp) {
                $excludeFolders[] = JPATH_SITE . '/tmp';
                $excludeFolders[] = JPATH_ADMINISTRATOR . '/tmp';
            }
            
            $backupStatus = $backupStatus && $this->backupFiles($backupPath, $excludeFolders, $backupFiles);
        }
        
        // Create a zip archive of all backup files
        $zipFile = $backupPath . '.zip';
        $backupStatus = $backupStatus && $this->createZipArchive($backupPath, $zipFile);
        
        // Calculate backup size
        if (File::exists($zipFile)) {
            $backupSize = filesize($zipFile);
        }
        
        // Remove the temporary backup folder
        Folder::delete($backupPath);
        
        // Save backup record to database
        $table = $this->getTable();
        $table->name = $backupName;
        $table->type = $backupType;
        $table->size = $backupSize;
        $table->path = $zipFile;
        $table->created = $date->toSql();
        $table->created_by = $user->id;
        $table->status = $backupStatus ? 'completed' : 'failed';
        
        if (!$table->store()) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_SAVING_BACKUP_RECORD'), 'error');
            return false;
        }
        
        return $backupStatus;
    }
    
    /**
     * Method to backup the database
     *
     * @param   string  $backupPath   Path to store the backup
     * @param   array   &$backupFiles Array of backup files
     *
     * @return  boolean  True on success, false on failure
     */
    protected function backupDatabase($backupPath, &$backupFiles)
    {
        $app = Factory::getApplication();
        $config = Factory::getConfig();
        
        // Get database connection details
        $dbType = $config->get('dbtype');
        $dbHost = $config->get('host');
        $dbUser = $config->get('user');
        $dbPass = $config->get('password');
        $dbName = $config->get('db');
        $dbPrefix = $config->get('dbprefix');
        
        // Set the backup file path
        $backupFile = $backupPath . '/database.sql';
        
        // Create the SQL file
        $handle = fopen($backupFile, 'w');
        if (!$handle) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_CREATING_DATABASE_BACKUP_FILE'), 'error');
            return false;
        }
        
        // Write header information
        fwrite($handle, "-- Joomla Database Backup\n");
        fwrite($handle, "-- Generated: " . date('Y-m-d H:i:s') . "\n");
        fwrite($handle, "-- Joomla Version: " . JVERSION . "\n");
        fwrite($handle, "-- Database: " . $dbName . "\n");
        fwrite($handle, "-- Database Prefix: " . $dbPrefix . "\n\n");
        
        // Get the database connection
        $db = Factory::getDbo();
        
        // Get all tables
        $tables = $db->getTableList();
        
        // Filter tables with the Joomla prefix
        $joomlaTables = [];
        foreach ($tables as $table) {
            if (strpos($table, $dbPrefix) === 0) {
                $joomlaTables[] = $table;
            }
        }
        
        // Process each table
        foreach ($joomlaTables as $table) {
            // Get the create table statement
            $db->setQuery('SHOW CREATE TABLE ' . $db->quoteName($table));
            $createTable = $db->loadRow();
            
            if ($createTable) {
                // Write the drop table statement
                fwrite($handle, "DROP TABLE IF EXISTS " . $db->quoteName($table) . ";\n");
                
                // Write the create table statement
                fwrite($handle, $createTable[1] . ";\n\n");
                
                // Get the table data
                $db->setQuery('SELECT * FROM ' . $db->quoteName($table));
                $rows = $db->loadObjectList();
                
                if ($rows) {
                    // Get the column names
                    $db->setQuery('SHOW COLUMNS FROM ' . $db->quoteName($table));
                    $columns = $db->loadObjectList();
                    $columnNames = [];
                    
                    foreach ($columns as $column) {
                        $columnNames[] = $column->Field;
                    }
                    
                    // Write the insert statements
                    foreach ($rows as $row) {
                        $values = [];
                        
                        foreach ($columnNames as $columnName) {
                            $value = $row->$columnName;
                            
                            if (is_null($value)) {
                                $values[] = 'NULL';
                            } elseif (is_numeric($value)) {
                                $values[] = $value;
                            } else {
                                $values[] = $db->quote($value);
                            }
                        }
                        
                        fwrite($handle, "INSERT INTO " . $db->quoteName($table) . " VALUES (" . implode(', ', $values) . ");\n");
                    }
                    
                    fwrite($handle, "\n");
                }
            }
        }
        
        // Close the file
        fclose($handle);
        
        // Add to backup files
        $backupFiles[] = $backupFile;
        
        return true;
    }
    
    /**
     * Method to backup files
     *
     * @param   string  $backupPath     Path to store the backup
     * @param   array   $excludeFolders Folders to exclude
     * @param   array   &$backupFiles   Array of backup files
     *
     * @return  boolean  True on success, false on failure
     */
    protected function backupFiles($backupPath, $excludeFolders, &$backupFiles)
    {
        $app = Factory::getApplication();
        
        // Create the files directory
        $filesDir = $backupPath . '/files';
        if (!Folder::create($filesDir)) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_CREATING_FILES_BACKUP_DIR'), 'error');
            return false;
        }
        
        // Copy the Joomla files
        $sourceDir = JPATH_ROOT;
        $excludeFolders[] = $backupPath;
        $excludeFolders[] = JPATH_ADMINISTRATOR . '/components/com_jbackup/backups';
        
        try {
            Folder::copy($sourceDir, $filesDir, '', true, $excludeFolders);
        } catch (Exception $e) {
            $app->enqueueMessage(Text::sprintf('COM_JBACKUP_ERROR_COPYING_FILES', $e->getMessage()), 'error');
            return false;
        }
        
        // Add to backup files
        $backupFiles[] = $filesDir;
        
        return true;
    }
    
    /**
     * Method to create a zip archive
     *
     * @param   string  $sourcePath  Source path
     * @param   string  $zipFile     Zip file path
     *
     * @return  boolean  True on success, false on failure
     */
    protected function createZipArchive($sourcePath, $zipFile)
    {
        $app = Factory::getApplication();
        
        // Create a new ZipArchive object
        $zip = new ZipArchive();
        
        // Open the zip file
        if ($zip->open($zipFile, ZipArchive::CREATE) !== true) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_CREATING_ZIP_ARCHIVE'), 'error');
            return false;
        }
        
        // Add the files
        $this->addFolderToZip($zip, $sourcePath, '');
        
        // Close the zip file
        $zip->close();
        
        return true;
    }
    
    /**
     * Method to add a folder to a zip archive
     *
     * @param   ZipArchive  $zip         Zip archive object
     * @param   string      $folderPath  Folder path
     * @param   string      $zipPath     Path within the zip
     *
     * @return  void
     */
    protected function addFolderToZip($zip, $folderPath, $zipPath)
    {
        $folderPath = rtrim($folderPath, '/\\') . '/';
        $zipPath = rtrim($zipPath, '/\\');
        
        // Add the directory itself
        if (!empty($zipPath)) {
            $zip->addEmptyDir($zipPath);
        }
        
        // Loop through all files and folders
        $handle = opendir($folderPath);
        
        while (false !== ($entry = readdir($handle))) {
            if ($entry == '.' || $entry == '..') {
                continue;
            }
            
            $entryPath = $folderPath . $entry;
            $zipEntryPath = $zipPath . ($zipPath ? '/' : '') . $entry;
            
            if (is_file($entryPath)) {
                $zip->addFile($entryPath, $zipEntryPath);
            } elseif (is_dir($entryPath)) {
                $this->addFolderToZip($zip, $entryPath, $zipEntryPath);
            }
        }
        
        closedir($handle);
    }
    
    /**
     * Method to download a backup
     *
     * @param   integer  $id  Backup ID
     *
     * @return  boolean  True on success, false on failure
     */
    public function downloadBackup($id)
    {
        $app = Factory::getApplication();
        
        // Get the backup record
        $table = $this->getTable();
        
        if (!$table->load($id)) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_BACKUP_NOT_FOUND'), 'error');
            return false;
        }
        
        // Check if the backup file exists
        if (!File::exists($table->path)) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_BACKUP_FILE_NOT_FOUND'), 'error');
            return false;
        }
        
        // Set the appropriate headers for download
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($table->path) . '"');
        header('Content-Length: ' . filesize($table->path));
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        // Read the file and output it to the browser
        readfile($table->path);
        
        // End the application
        $app->close();
        
        return true;
    }
    
    /**
     * Method to restore a backup
     *
     * @param   integer  $id  Backup ID
     *
     * @return  boolean  True on success, false on failure
     */
    public function restoreBackup($id)
    {
        $app = Factory::getApplication();
        
        // Get the backup record
        $table = $this->getTable();
        
        if (!$table->load($id)) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_BACKUP_NOT_FOUND'), 'error');
            return false;
        }
        
        // Check if the backup file exists
        if (!File::exists($table->path)) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_BACKUP_FILE_NOT_FOUND'), 'error');
            return false;
        }
        
        // Create a temporary directory for extraction
        $tempDir = JPATH_ADMINISTRATOR . '/components/com_jbackup/tmp/restore_' . uniqid();
        if (!Folder::create($tempDir)) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_CREATING_TEMP_DIR'), 'error');
            return false;
        }
        
        // Extract the backup
        $zip = new ZipArchive();
        if ($zip->open($table->path) !== true) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_OPENING_BACKUP_FILE'), 'error');
            Folder::delete($tempDir);
            return false;
        }
        
        $zip->extractTo($tempDir);
        $zip->close();
        
        // Restore database if it exists
        $databaseFile = $tempDir . '/database.sql';
        if (File::exists($databaseFile)) {
            if (!$this->restoreDatabase($databaseFile)) {
                $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_RESTORING_DATABASE'), 'error');
                Folder::delete($tempDir);
                return false;
            }
        }
        
        // Restore files if they exist
        $filesDir = $tempDir . '/files';
        if (Folder::exists($filesDir)) {
            if (!$this->restoreFiles($filesDir)) {
                $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_RESTORING_FILES'), 'error');
                Folder::delete($tempDir);
                return false;
            }
        }
        
        // Clean up
        Folder::delete($tempDir);
        
        return true;
    }
    
    /**
     * Method to restore the database
     *
     * @param   string  $databaseFile  Database SQL file
     *
     * @return  boolean  True on success, false on failure
     */
    protected function restoreDatabase($databaseFile)
    {
        $app = Factory::getApplication();
        $db = Factory::getDbo();
        
        // Read the SQL file
        $sql = file_get_contents($databaseFile);
        if (!$sql) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_READING_DATABASE_FILE'), 'error');
            return false;
        }
        
        // Split the SQL file into individual queries
        $queries = $this->splitSql($sql);
        
        // Execute each query
        foreach ($queries as $query) {
            $query = trim($query);
            
            if (!empty($query)) {
                $db->setQuery($query);
                
                try {
                    $db->execute();
                } catch (Exception $e) {
                    $app->enqueueMessage(Text::sprintf('COM_JBACKUP_ERROR_EXECUTING_QUERY', $e->getMessage()), 'error');
                    return false;
                }
            }
        }
        
        return true;
    }
    
    /**
     * Method to split SQL into individual queries
     *
     * @param   string  $sql  SQL string
     *
     * @return  array   Array of queries
     */
    protected function splitSql($sql)
    {
        $queries = [];
        $currentQuery = '';
        $inString = false;
        $stringChar = '';
        
        // Loop through each character
        for ($i = 0; $i < strlen($sql); $i++) {
            $char = $sql[$i];
            $nextChar = isset($sql[$i + 1]) ? $sql[$i + 1] : '';
            
            // Handle string delimiters
            if (($char == "'" || $char == '"') && ($i == 0 || $sql[$i - 1] != '\\')) {
                if ($inString && $stringChar == $char) {
                    $inString = false;
                } elseif (!$inString) {
                    $inString = true;
                    $stringChar = $char;
                }
            }
            
            // Add the character to the current query
            $currentQuery .= $char;
            
            // If we're at a semicolon and not in a string, end the query
            if ($char == ';' && !$inString) {
                $queries[] = $currentQuery;
                $currentQuery = '';
            }
        }
        
        // Add any remaining query
        if (!empty($currentQuery)) {
            $queries[] = $currentQuery;
        }
        
        return $queries;
    }
    
    /**
     * Method to restore files
     *
     * @param   string  $filesDir  Files directory
     *
     * @return  boolean  True on success, false on failure
     */
    protected function restoreFiles($filesDir)
    {
        $app = Factory::getApplication();
        
        // Get the Joomla root directory
        $rootDir = JPATH_ROOT;
        
        // Copy the files
        try {
            Folder::copy($filesDir, $rootDir, '', true);
        } catch (Exception $e) {
            $app->enqueueMessage(Text::sprintf('COM_JBACKUP_ERROR_COPYING_FILES', $e->getMessage()), 'error');
            return false;
        }
        
        return true;
    }
    
    /**
     * Method to delete a backup
     *
     * @param   integer  $id  Backup ID
     *
     * @return  boolean  True on success, false on failure
     */
    public function deleteBackup($id)
    {
        $app = Factory::getApplication();
        
        // Get the backup record
        $table = $this->getTable();
        
        if (!$table->load($id)) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_BACKUP_NOT_FOUND'), 'error');
            return false;
        }
        
        // Delete the backup file if it exists
        if (File::exists($table->path)) {
            if (!File::delete($table->path)) {
                $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_DELETING_BACKUP_FILE'), 'error');
                return false;
            }
        }
        
        // Delete the backup record
        if (!$table->delete()) {
            $app->enqueueMessage(Text::_('COM_JBACKUP_ERROR_DELETING_BACKUP_RECORD'), 'error');
            return false;
        }
        
        return true;
    }
}
